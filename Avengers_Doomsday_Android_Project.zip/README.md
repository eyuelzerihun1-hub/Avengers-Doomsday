# Avengers: Doomsday Android app

This is an Android WebView app that bundles the complete viewing roadmap inside the APK.
It works offline because the HTML and roadmap data are packaged in `app/src/main/assets/index.html`.
Viewing progress is stored locally on the device using WebView DOM storage.

## Build the APK in GitHub Actions (no Android Studio required on your phone)
1. Create a GitHub account if needed.
2. Create a new repository and upload the contents of this folder to its `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and press **Run workflow** (or wait for the first push build).
5. Open the completed workflow run and download the `Avengers-Doomsday-APK` artifact.
6. Extract the artifact ZIP; it contains `app-debug.apk`.
7. Open the APK on Android and allow installation from that source if Android asks.

This is a debug-signed APK for personal installation, not a Play Store release.
